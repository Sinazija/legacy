from normalize import normalize
import file_parser as parser

